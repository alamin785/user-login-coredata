//
//  userhelper.swift
//  userlogincoredata
//
//  Created by alamin on 3/4/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import Foundation
import CoreData
import UIKit
class datahelper{
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
   static var share = datahelper()
    
    func save(object : [String:String]){
        let user = NSEntityDescription.insertNewObject(forEntityName: "User", into: context!) as! User
        
        user.username = object["username"]
        user.password = object["password"]
        
        do {
            try context?.save()
        } catch{
            print("error")
        }
    }
}
