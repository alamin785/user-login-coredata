//
//  secodViewController.swift
//  userlogincoredata
//
//  Created by alamin on 3/5/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import UIKit

class secodViewController: UIViewController {

    @IBOutlet weak var back: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

 self.roundback(btn3: back)

}
    
    func roundback(btn3:AnyObject){
    
    if #available(iOS 12.0, *) {
    btn3.layer.cornerRadius = btn3.frame.size.height
    } else {
    }
    btn3.layer.masksToBounds = true
}
    
    
}
