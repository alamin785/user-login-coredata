//
//  ViewController.swift
//  userlogincoredata
//
//  Created by alamin on 3/3/19.
//  Copyright © 2019 alamin. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

   
    @IBOutlet weak var logoutlet: UIButton!
    
    @IBOutlet weak var loginoutlet: UIButton!
    
    @IBOutlet weak var passoutlet: UITextField!
    
    @IBOutlet weak var useroutlet: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.roundlogin(btn1: loginoutlet)
         self.roundlogout(btn2: logoutlet)
   alert()
    }
        

    @IBAction func loginaction(_ sender: Any) {
        alert()
    
    let dic = ["username":useroutlet.text,"password":passoutlet.text]
        
        datahelper.share.save(object: dic as! [String : String])
        
        
       
   
    }

    
    
    
    func roundlogin(btn1:AnyObject) {
        
        if #available(iOS 12.0, *) {
            btn1.layer.cornerRadius = btn1.frame.size.height/2
        } else {
           
        }
        btn1.layer.masksToBounds = true
    }
    
    
    
    func roundlogout(btn2:AnyObject) {
        
        if #available(iOS 12.0, *) {
            btn2.layer.cornerRadius = btn2.frame.size.height/2
        } else {
           
        }
        btn2.layer.masksToBounds = true
    }
    
    @IBAction func next(_ sender: Any) {
      
        if useroutlet.text=="" && passoutlet.text == ""{
            print("empty")
        }else if useroutlet.text!==""{
            performSegue(withIdentifier: "second", sender: self)
        }else if passoutlet.text!==""{
            performSegue(withIdentifier: "second", sender: self)
        }
        func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            segue.destination as? secodViewController
            
            
        }
      
    
        performSegue(withIdentifier: "second", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        segue.destination as? secodViewController
      
    }
    func alert() {
        let alert = UIAlertController(title:"Empty text field", message: "input your text", preferredStyle: .alert)
        let diss = UIAlertAction(title: "dismiss", style: .cancel, handler: {
            (alert:UIAlertAction)-> Void in
        })
        alert.addAction(diss)
        self.present(alert,animated: true,completion: nil)
    }

    }
    
    






