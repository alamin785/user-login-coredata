//
//  User+CoreDataClass.swift
//  userlogincoredata
//
//  Created by alamin on 3/4/19.
//  Copyright © 2019 alamin. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
